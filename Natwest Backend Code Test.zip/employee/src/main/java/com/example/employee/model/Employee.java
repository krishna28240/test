package com.example.employee.model;

import lombok.Value;

@Value
public class Employee {
    String userId;
    String firstName;
    String lastName;
}
