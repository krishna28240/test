package com.example.employee.model;

public enum ErrorCode {
    EMPLOYEE_NOT_FOUND
}
